

const storeSliderValues = () => {

};

const restoreSliderValues = () => {

};

const storeSwatches = () => {
    // bouw een array met kleurinfo objecten

};

const restoreSwatches = () => {

};
